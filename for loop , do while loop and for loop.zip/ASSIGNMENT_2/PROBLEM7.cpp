#include <iostream>
using namespace std;

int main() {
    int count = 0;
    int sum = 0;
    int value = 0;

    for (; value != 9999; count++) {
        cout << "Enter value (9999 to exit): ";
        cin >> value;

        if (value != 9999) {
            sum += value;
        }
    }

    if (count == 0) {
        cout << "No values entered." << endl;
    } else {
        double average = static_cast<double>(sum) / count;
        cout << "The average OF numbers before 9999 is: " << average << endl;
    }

    return 0;
}

