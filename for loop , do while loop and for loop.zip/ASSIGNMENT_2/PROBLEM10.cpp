#include <iostream>
using namespace std;

int main() {
    for (int n = 1; n <= 5; n++) {
        int factorial = 1;
        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        cout << n << "! = " << factorial << endl;
    }
    return 0;
}

