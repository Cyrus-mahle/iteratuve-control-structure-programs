#include <iostream>
using namespace std;

int main() {
    int counter = 1;
    int largest = 0;
    int number;

    while (counter <= 10) {
        cout << "Enter number " << counter << ": ";
        cin >> number;
        if (number > largest) {
            largest = number;
        }
        counter++;
    }

    cout << "The largest number is: " << largest << endl;

    return 0;
}

