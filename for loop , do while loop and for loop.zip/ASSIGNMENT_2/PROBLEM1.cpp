#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double total_kms = 0, total_litres = 0;
    int count = 0;
    double kms, litres;

    cout << fixed << setprecision(4); // set output precision to 4 decimal places

    cout << "Enter the litres used (-1 to end): ";
    cin >> litres;

    while (litres != -1) {
        cout << "Enter the kilometres driven: ";
        cin >> kms;

        double kms_per_litre = kms / litres;
        cout << "The Kilometres / Litre for this tank was " << kms_per_litre << endl;

        total_kms += kms;
        total_litres += litres;
        count++;

        cout << "Enter the litres used (-1 to end): ";
        cin >> litres;
    }

    if (count > 0) {
        double overall_kms_per_litre = total_kms / total_litres;
        cout << "The overall average Kilometres/Litre was " << overall_kms_per_litre << endl;
    } else {
        cout << "No data was entered." << endl;
    }

    return 0;
}

