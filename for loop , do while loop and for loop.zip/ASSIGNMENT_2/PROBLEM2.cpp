#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int account_number;
    double beginning_balance, total_charges, total_credits, credit_limit;

    cout << fixed << setprecision(2); // set output precision to 2 decimal places

    cout << "Enter account number (-1 to end): ";
    cin >> account_number;

    while (account_number != -1) {
        cout << "Enter beginning balance: ";
        cin >> beginning_balance;

        cout << "Enter total charges: ";
        cin >> total_charges;

        cout << "Enter total credits: ";
        cin >> total_credits;

        cout << "Enter credit limit: ";
        cin >> credit_limit;

        double new_balance = beginning_balance + total_charges - total_credits;

        cout << "New balance is " << new_balance << endl;

        if (new_balance > credit_limit) {
            cout << "Account: " << account_number << endl;
            cout << "Credit limit: " << credit_limit << endl;
            cout << "Balance: " << new_balance << endl;
            cout << "Credit Limit Exceeded." << endl;
        }

        cout << "Enter account number (-1 to end): ";
        cin >> account_number;
    }

    return 0;
}

