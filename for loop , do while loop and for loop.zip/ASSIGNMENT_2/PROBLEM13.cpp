#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    const double PRICE1 = 2.98;
    const double PRICE2 = 4.50;
    const double PRICE3 = 9.98;
    const double PRICE4 = 4.49;
    const double PRICE5 = 6.87;
   
    int product;
    int quantity;
    double total = 0.0;
    cout << "Product  Price " << endl;
    cout << " 1       " <<"2.98" << endl;
	cout << " 2       " <<"4.50" << endl;
	cout << " 3       " <<"9.98" << endl;
	cout << " 4       " <<"4.49" << endl;
	cout << " 5       " <<"6.87" << endl;
	        
    cout << fixed << setprecision(2);

    while (true) {
        cout << "Enter product number (1-5, 0 to stop): ";
        cin >> product;

        if (product == 0) {
            break;
        }

        cout << "Enter quantity sold: ";
        cin >> quantity;

        switch (product) {
            case 1:
                total += PRICE1 * quantity;
                break;
            case 2:
                total += PRICE2 * quantity;
                break;
            case 3:
                total += PRICE3 * quantity;
                break;
            case 4:
                total += PRICE4 * quantity;
                break;
            case 5:
                total += PRICE5 * quantity;
                break;
            default:
                cout << "Invalid product number." << endl;
        }
    }

    cout << "Total retail value of all products sold: R" << total << endl;

    return 0;
}

