#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main() {
    double principal = 1000.0;
    for (double rate = 0.05; rate <= 0.1; rate += 0.01) {
        cout << "Interest rate: " << rate << endl;
        cout << setw(5) << "Year" << setw(21) << "Amount on deposit" << endl;
        cout << fixed << setprecision(2);
        for (int year = 1; year <= 10; year++) {
            double amount = principal * pow(1.0 + rate, year);
            cout << setw(5) << year << setw(21) << amount << endl;
        }
        cout << endl;
    }
    return 0;
}

