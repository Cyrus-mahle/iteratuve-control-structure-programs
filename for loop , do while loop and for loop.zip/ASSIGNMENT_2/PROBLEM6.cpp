#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of values to be summed: ";
    cin >> n;

    int sum = 0;
    for (int i = 0; i < n; i++) {
        int value;
        cout << "Enter value " << i+1 << ": ";
        cin >> value;
        sum += value;
    }

    cout << "The sum is: " << sum << endl;
    return 0;
}

