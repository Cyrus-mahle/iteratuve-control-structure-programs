#include <iostream>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of values to compare: ";
    cin >> n;

    int smallest;
    cout << "Enter value 1: ";
    cin >> smallest;

    for (int i = 2; i <= n; i++) {
        int value;
        cout << "Enter value " << i << ": ";
        cin >> value;

        if (value < smallest) {
            smallest = value;
        }
    }

    cout << "The smallest value is: " << smallest << endl;
    return 0;
}


