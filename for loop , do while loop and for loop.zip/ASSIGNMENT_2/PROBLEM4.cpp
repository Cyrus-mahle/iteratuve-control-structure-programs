#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int hoursWorked;
    double hourlyRate, grossPay;

    cout << fixed << setprecision(2);

    // Input hours worked
    cout << "Enter hours worked (-1 to end): ";
    cin >> hoursWorked;

    while (hoursWorked != -1) {
        // Input hourly rate
        cout << "Enter hourly rate of the worker (R00.00): ";
        cin >> hourlyRate;

        // Calculate gross pay
        if (hoursWorked <= 40) {
            grossPay = hoursWorked * hourlyRate;
        } else {
            grossPay = 40 * hourlyRate + (hoursWorked - 40) * hourlyRate * 1.5;
        }

        // Output gross pay
        cout << "Salary is R" << grossPay << endl;

        // Input next hours worked
        cout << "Enter hours worked (-1 to end): ";
        cin >> hoursWorked;
    }

    return 0;
}

