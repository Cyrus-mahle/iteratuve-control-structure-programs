#include <iostream>
#include <iomanip>  // for std::fixed and std::setprecision

int main() {
    double sales = 0.0;
    const double BASE_SALARY = 200.0;
    const double COMMISSION_RATE = 0.09;

    std::cout << "Enter sales in rands (-1 to end): ";
    std::cin >> sales;

    while (sales != -1.0) {
        double salary = BASE_SALARY + (sales * COMMISSION_RATE);
        std::cout << "Salary is: R" << std::fixed << std::setprecision(2) << salary << std::endl;

        std::cout << "Enter sales in rands (-1 to end): ";
        std::cin >> sales;
    }

    return 0;
}

